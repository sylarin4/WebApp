﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library.Data
{
    public class UserDTO
    {
        public String UserName { get; set; }
        public String UserPassword { get; set; }

        public int? Id { get; set; }
    }
}

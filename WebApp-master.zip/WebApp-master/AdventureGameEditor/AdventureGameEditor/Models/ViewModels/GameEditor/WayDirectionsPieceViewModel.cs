﻿using System;

namespace AdventureGameEditor.Models.ViewModels.GameEditor
{
    public class WayDirectionsPieceViewModel
    {
        public String GameTitle { get; set; }
        public int WayDirectionsCode {get;set;}
    }
}

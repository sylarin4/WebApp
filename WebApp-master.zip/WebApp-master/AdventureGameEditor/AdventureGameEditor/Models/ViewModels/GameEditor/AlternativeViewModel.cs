﻿using AdventureGameEditor.Models.DatabaseModels.Game;

namespace AdventureGameEditor.Models.ViewModels.GameEditor
{
    public class AlternativeViewModel
    {
        public Trial Trial { get; set; }
        public int Index { get; set; }
    }
}

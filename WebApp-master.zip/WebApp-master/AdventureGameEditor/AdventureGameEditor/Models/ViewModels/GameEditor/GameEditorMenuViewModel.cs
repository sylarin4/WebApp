﻿using System;

namespace AdventureGameEditor.Models.ViewModels.GameEditor
{
    public class GameEditorMenuViewModel
    {
        public String GameTitle { get; set; }
    }
}

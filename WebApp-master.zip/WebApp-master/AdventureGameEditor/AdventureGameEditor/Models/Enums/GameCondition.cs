﻿namespace AdventureGameEditor.Models.Enums
{
    public enum GameCondition
    {
        OnGoing,
        Won,
        Lost
    }
}

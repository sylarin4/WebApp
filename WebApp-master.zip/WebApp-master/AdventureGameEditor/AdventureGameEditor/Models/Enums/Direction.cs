﻿namespace AdventureGameEditor.Models.Enums
{
    public enum Direction
    {
        Up, 
        Down,
        Right,
        Left,
        NotSet
    }
}

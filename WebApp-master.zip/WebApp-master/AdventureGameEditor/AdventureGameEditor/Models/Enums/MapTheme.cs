﻿namespace AdventureGameEditor.Models.Enums 
{ 
    public enum MapTheme
    {
        Test,
        Default
    }
}

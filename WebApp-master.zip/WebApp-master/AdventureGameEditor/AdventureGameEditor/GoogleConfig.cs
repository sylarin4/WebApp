﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdventureGameEditor
{
    public class GoogleConfig
    {
        public string MapsApiKey { get; set; }
    }
}
